//
//  Scrumdinger_App.swift
//  Scrumdinger,
//
//  Created by سرّاء. on 24/06/1444 AH.
//

import SwiftUI

@main
struct Scrumdinger_App: App {
    var body: some Scene {
        WindowGroup {
            MeetingView()
        }
    }
}
