//
//  Assigmnent_ScrumdingerApp.swift
//  Assigmnent-Scrumdinger
//
//  Created by N on 17/01/2023.
//

import SwiftUI

@main
struct Assigmnent_ScrumdingerApp: App {
    var body: some Scene {
        WindowGroup {
            MeetingView()
        }
    }
}
